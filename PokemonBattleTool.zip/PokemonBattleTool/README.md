# PokemonBattleTool - 宝可梦对战工具

## 功能
- 宝可梦搜索查询
- 种族值可视化对比
- 常用配招推荐
- 属性克制查询

## 技术栈
- Kotlin + Jetpack Compose
- Material 3 Design
- 离线数据（内置常用宝可梦）

## 安装运行
1. 用 Android Studio 打开项目
2. 同步 Gradle
3. 运行到设备或模拟器

## 数据来源
- 内置前150+常用对战宝可梦数据
- 种族值和配招基于 Smogon OU/UU 数据