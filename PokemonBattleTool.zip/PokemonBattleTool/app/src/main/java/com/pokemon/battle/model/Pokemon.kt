package com.pokemon.battle.model

data class Pokemon(
    val id: Int,
    val name: String,
    val nameCn: String,
    val types: List<String>,
    val stats: Stats,
    val moves: List<Move>,
    val abilities: List<String>,
    val tier: String // OU/UU/RU/NU等
)

data class Stats(
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val spAtk: Int,
    val spDef: Int,
    val speed: Int
) {
    val total: Int get() = hp + attack + defense + spAtk + spDef + speed
}

data class Move(
    val name: String,
    val nameCn: String,
    val type: String,
    val category: String, // Physical/Special/Status
    val power: Int?,
    val accuracy: Int,
    val description: String
)

// 属性克制表
object TypeChart {
    private val effectiveness = mapOf(
        "normal" to mapOf("rock" to 0.5, "ghost" to 0.0, "steel" to 0.5),
        "fire" to mapOf("fire" to 0.5, "water" to 0.5, "grass" to 2.0, "ice" to 2.0, "bug" to 2.0, "rock" to 0.5, "dragon" to 0.5, "steel" to 2.0),
        "water" to mapOf("fire" to 2.0, "water" to 0.5, "grass" to 0.5, "ground" to 2.0, "rock" to 2.0, "dragon" to 0.5),
        "electric" to mapOf("water" to 2.0, "electric" to 0.5, "grass" to 0.5, "ground" to 0.0, "flying" to 2.0, "dragon" to 0.5),
        "grass" to mapOf("fire" to 0.5, "water" to 2.0, "grass" to 0.5, "poison" to 0.5, "ground" to 2.0, "flying" to 0.5, "bug" to 0.5, "rock" to 2.0, "dragon" to 0.5, "steel" to 0.5),
        "ice" to mapOf("fire" to 0.5, "water" to 0.5, "grass" to 2.0, "ice" to 0.5, "ground" to 2.0, "flying" to 2.0, "dragon" to 2.0, "steel" to 0.5),
        "fighting" to mapOf("normal" to 2.0, "ice" to 2.0, "poison" to 0.5, "flying" to 0.5, "psychic" to 0.5, "bug" to 0.5, "rock" to 2.0, "ghost" to 0.0, "dark" to 2.0, "steel" to 2.0, "fairy" to 0.5),
        "poison" to mapOf("grass" to 2.0, "poison" to 0.5, "ground" to 0.5, "rock" to 0.5, "ghost" to 0.5, "steel" to 0.0, "fairy" to 2.0),
        "ground" to mapOf("fire" to 2.0, "electric" to 2.0, "grass" to 0.5, "poison" to 2.0, "flying" to 0.0, "bug" to 0.5, "rock" to 2.0, "steel" to 2.0),
        "flying" to mapOf("electric" to 0.5, "grass" to 2.0, "fighting" to 2.0, "bug" to 2.0, "rock" to 0.5, "steel" to 0.5),
        "psychic" to mapOf("fighting" to 2.0, "poison" to 2.0, "psychic" to 0.5, "dark" to 0.0, "steel" to 0.5),
        "bug" to mapOf("fire" to 0.5, "grass" to 2.0, "fighting" to 0.5, "poison" to 0.5, "flying" to 0.5, "psychic" to 2.0, "ghost" to 0.5, "dark" to 2.0, "steel" to 0.5, "fairy" to 0.5),
        "rock" to mapOf("fire" to 2.0, "ice" to 2.0, "fighting" to 0.5, "ground" to 0.5, "flying" to 2.0, "bug" to 2.0, "steel" to 0.5),
        "ghost" to mapOf("normal" to 0.0, "psychic" to 2.0, "ghost" to 2.0, "dark" to 0.5),
        "dragon" to mapOf("dragon" to 2.0, "steel" to 0.5, "fairy" to 0.0),
        "dark" to mapOf("fighting" to 0.5, "psychic" to 2.0, "ghost" to 2.0, "dark" to 0.5, "fairy" to 0.5),
        "steel" to mapOf("fire" to 0.5, "water" to 0.5, "electric" to 0.5, "ice" to 2.0, "rock" to 2.0, "steel" to 0.5, "fairy" to 2.0),
        "fairy" to mapOf("fire" to 0.5, "fighting" to 2.0, "poison" to 0.5, "dragon" to 2.0, "dark" to 2.0, "steel" to 0.5)
    )

    fun getEffectiveness(attackType: String, defenseTypes: List<String>): Double {
        var multiplier = 1.0
        defenseTypes.forEach { defenseType ->
            multiplier *= effectiveness[attackType.lowercase()]?.get(defenseType.lowercase()) ?: 1.0
        }
        return multiplier
    }

    fun getTypeColor(type: String): Long {
        return when(type.lowercase()) {
            "normal" -> 0xFFA8A878
            "fire" -> 0xFFF08030
            "water" -> 0xFF6890F0
            "electric" -> 0xFFF8D030
            "grass" -> 0xFF78C850
            "ice" -> 0xFF98D8D8
            "fighting" -> 0xFFC03028
            "poison" -> 0xFFA040A0
            "ground" -> 0xFFE0C068
            "flying" -> 0xFFA890F0
            "psychic" -> 0xFFF85888
            "bug" -> 0xFFA8B820
            "rock" -> 0xFFB8A038
            "ghost" -> 0xFF705898
            "dragon" -> 0xFF7038F8
            "dark" -> 0xFF705848
            "steel" -> 0xFFB8B8D0
            "fairy" -> 0xFFEE99AC
            else -> 0xFF68A090
        }
    }
}