package com.pokebattletool

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.pokebattletool.data.remote.PokeApiService
import com.pokebattletool.data.repository.PokemonRepository
import com.pokebattletool.ui.navigation.AppNavGraph
import com.pokebattletool.ui.theme.PokemonBattleToolTheme
import com.pokebattletool.ui.viewmodel.MainViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val api = Retrofit.Builder()
            .baseUrl("https://pokeapi.co/api/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PokeApiService::class.java)
        val repository = PokemonRepository(api)
        val viewModel = MainViewModel(repository)

        setContent {
            PokemonBattleToolTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppNavGraph(navController = navController, viewModel = viewModel)
                }
            }
        }
    }
}
