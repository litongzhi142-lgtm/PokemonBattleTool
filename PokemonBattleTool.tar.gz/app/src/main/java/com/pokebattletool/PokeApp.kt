package com.pokebattletool

import android.app.Application

class PokeApp : Application()
