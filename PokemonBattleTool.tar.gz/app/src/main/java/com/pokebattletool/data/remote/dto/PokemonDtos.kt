package com.pokebattletool.data.remote.dto

import com.google.gson.annotations.SerializedName

data class PokemonDetailDto(
    val id: Int,
    val name: String,
    val types: List<TypeSlot>,
    val stats: List<StatDto>,
    val sprites: Sprites,
    val moves: List<MoveSlot>
)

data class TypeSlot(val slot: Int, val type: ApiRef)
data class StatDto(
    @SerializedName("base_stat") val baseStat: Int,
    val effort: Int,
    val stat: ApiRef
)
data class Sprites(
    @SerializedName("front_default") val frontDefault: String?,
    val other: OtherSprites?
)
data class OtherSprites(
    @SerializedName("official-artwork") val officialArtwork: OfficialArtwork?
)
data class OfficialArtwork(@SerializedName("front_default") val frontDefault: String?)
data class MoveSlot(val move: ApiRef)
data class ApiRef(val name: String, val url: String)

data class PokemonSpeciesDto(
    val id: Int,
    val names: List<NameEntry>,
    @SerializedName("flavor_text_entries") val flavorTextEntries: List<FlavorText>
)
data class NameEntry(val name: String, val language: ApiRef)
data class FlavorText(
    @SerializedName("flavor_text") val flavorText: String,
    val language: ApiRef
)

data class PokemonListDto(val count: Int, val results: List<ApiRef>)
