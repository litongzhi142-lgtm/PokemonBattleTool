package com.pokebattletool.data.repository

import com.pokebattletool.data.remote.PokeApiService
import com.pokebattletool.data.local.MoveSetDatabase
import com.pokebattletool.domain.model.*

class PokemonRepository(private val api: PokeApiService) {

    suspend fun searchPokemon(query: String): Pokemon? {
        return try {
            val name = query.lowercase().trim()
                .let { ChineseNameMapper.toEnglish(it) ?: it }
            val dto = api.getPokemon(name)
            convertToPokemon(dto)
        } catch (e: Exception) {
            null
        }
    }

    fun getMoveSets(pokemonName: String): List<MoveSet> =
        MoveSetDatabase.getMoveSets(pokemonName)

    fun getPopularPokemon(): List<String> =
        MoveSetDatabase.getAllPokemonNames()

    private suspend fun convertToPokemon(dto: com.pokebattletool.data.remote.dto.PokemonDetailDto): Pokemon {
        val chineseName = try {
            val species = api.getPokemonSpecies(dto.id)
            species.names.find {
                it.language.name == "zh-Hans" || it.language.name == "zh-Hant"
            }?.name ?: ChineseNameMapper.toChinese(dto.name) ?: dto.name
        } catch (e: Exception) {
            ChineseNameMapper.toChinese(dto.name) ?: dto.name
        }

        val flavorText = try {
            val species = api.getPokemonSpecies(dto.id)
            species.flavorTextEntries
                .find { it.language.name == "zh-Hans" || it.language.name == "zh-Hant" }
                ?.flavorText?.replace("\n", " ")?.replace("\u000C", " ")
        } catch (e: Exception) { null }

        val types = dto.types.mapNotNull {
            try { PokeType.valueOf(it.type.name.uppercase()) } catch (e: Exception) { null }
        }

        val stats = BaseStats(
            hp = dto.stats.find { it.stat.name == "hp" }?.baseStat ?: 0,
            attack = dto.stats.find { it.stat.name == "attack" }?.baseStat ?: 0,
            defense = dto.stats.find { it.stat.name == "defense" }?.baseStat ?: 0,
            spAtk = dto.stats.find { it.stat.name == "special-attack" }?.baseStat ?: 0,
            spDef = dto.stats.find { it.stat.name == "special-defense" }?.baseStat ?: 0,
            speed = dto.stats.find { it.stat.name == "speed" }?.baseStat ?: 0
        )

        val imageUrl = dto.sprites.other?.officialArtwork?.frontDefault
            ?: dto.sprites.frontDefault

        return Pokemon(dto.id, dto.name, chineseName, types, stats, imageUrl, flavorText)
    }
}

object ChineseNameMapper {
    private val map = mapOf(
        "bulbasaur" to "妙蛙种子", "ivysaur" to "妙蛙草", "venusaur" to "妙蛙花",
        "charmander" to "小火龙", "charmeleon" to "火恐龙", "charizard" to "喷火龙",
        "squirtle" to "杰尼龟", "wartortle" to "卡咪龟", "blastoise" to "水箭龟",
        "pikachu" to "皮卡丘", "raichu" to "雷丘",
        "alakazam" to "胡地", "machamp" to "怪力",
        "gengar" to "耿鬼", "onix" to "大岩蛇",
        "slowbro" to "呆壳兽", "cloyster" to "刺甲贝",
        "gyarados" to "暴鲤龙", "lapras" to "拉普拉斯",
        "eevee" to "伊布", "vaporeon" to "水伊布", "jolteon" to "雷伊布", "flareon" to "火伊布",
        "snorlax" to "卡比兽", "dragonite" to "快龙", "mewtwo" to "超梦", "mew" to "梦幻",
        "scizor" to "巨钳螳螂", "kingdra" to "刺龙王", "skarmory" to "盔甲鸟",
        "blissey" to "幸福蛋", "lugia" to "洛奇亚", "ho-oh" to "凤王",
        "sceptile" to "蜥蜴王", "blaziken" to "火焰鸡", "swampert" to "巨沼怪",
        "gardevoir" to "沙奈朵", "metagross" to "巨金怪", "rayquaza" to "烈空坐",
        "lucario" to "路卡利欧", "garchomp" to "烈咬陆鲨",
        "tangrowth" to "藤蔓怪", "gliscor" to "天蝎王",
        "rotom" to "洛托姆", "rotom-wash" to "清洗洛托姆",
        "volcarona" to "火神蛾", "ferrothorn" to "坚果哑铃",
        "conkeldurr" to "修建老匠", "darmanitan" to "达摩狒狒",
        "tornadus" to "龙卷云", "tornadus-therian" to "灵兽龙卷云",
        "landorus" to "土地云", "landorus-therian" to "灵兽土地云",
        "greninja" to "甲贺忍蛙", "aegislash" to "坚盾剑怪",
        "sylveon" to "仙子伊布", "tyranitar" to "班基拉斯",
        "excadrill" to "龙头地鼠", "toxapex" to "超坏星",
        "magearna" to "玛机雅娜", "tapu-koko" to "卡璞鸣鸣",
        "tapu-lele" to "卡璞蝶蝶", "tapu-bulu" to "卡璞哞哞",
        "tapu-fini" to "卡璞鳍鳍",
        "celesteela" to "铁火辉夜", "kartana" to "纸御剑",
        "marshadow" to "玛夏多", "necrozma" to "奈克洛兹玛",
        "rillaboom" to "轰擂金刚猩", "cinderace" to "闪焰王牌",
        "corviknight" to "钢铠鸦", "dragapult" to "多龙巴鲁托",
        "zacian" to "苍响", "zamazenta" to "藏玛然特",
        "urshifu" to "武道熊师", "urshifu-rapid-strike" to "连击流武道熊师",
        "meowscarada" to "魔幻假面喵", "skeledirge" to "骨纹巨声鳄",
        "kingambit" to "仆刀将军", "glimmora" to "晶光花",
        "baxcalibur" to "戟脊龙", "annihilape" to "弃世猴",
        "pawmot" to "布土拨", "roaring-moon" to "吼叫尾",
        "iron-valiant" to "铁臂膀", "iron-hands" to "铁臂膀",
        "great-tusk" to "古鼎鹿", "scream-tail" to "古剑豹",
        "flutter-mane" to "猛雷鼓", "slither-wing" to "爬地翅",
        "koraidon" to "故勒顿", "miraidon" to "密勒顿",
        "wo-chien" to "古简蜗", "chien-pao" to "古剑豹",
        "ting-lu" to "古鼎鹿", "chi-yu" to "古玉鱼",
        "archaludon" to "铝钢桥龙", "hydrapple" to "蜜集大蛇",
        "clodsire" to "狠辣椒", "dondozo" to "吃吼霸",
        "heatran" to "席多蓝恩", "clefable" to "皮可西",
        "hydreigon" to "三首恶龙", "weavile" to "玛狃拉",
        "ampharos" to "电龙", "espeon" to "太阳伊布", "umbreon" to "月亮伊布",
        "heracross" to "赫拉克罗斯", "suicune" to "水君",
        "feraligatr" to "大力鳄", "meganium" to "大竺葵",
        "typhlosion" to "火暴兽", "empoleon" to "帝王拿波",
        "infernape" to "烈焰猴", "torterra" to "土台龟",
        "electivire" to "电击魔兽", "mamoswine" to "象牙猪",
        "cresselia" to "克雷色利亚", "darkrai" to "达克莱伊",
        "samurott" to "大剑鬼", "emboar" to "炎武王",
        "serperior" to "君主蛇", "delphox" to "妖火红狐",
        "chesnaught" to "布里卡隆", "diancie" to "蒂安希",
        "decidueye" to "狙射树枭", "incineroar" to "炽焰咆哮虎",
        "primarina" to "西狮海壬"
    )

    fun toChinese(englishName: String): String? = map[englishName.lowercase()]
    fun toEnglish(chineseName: String): String? =
        map.entries.find { it.value == chineseName }?.key
}
