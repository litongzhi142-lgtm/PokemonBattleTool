package com.pokebattletool.data.local

import com.pokebattletool.domain.model.MoveSet

object MoveSetDatabase {
    val allMoveSets: Map<String, List<MoveSet>> = mapOf(
        "dragapult" to listOf(
            MoveSet("dragapult", "腮攻", "压迫感", "讲究围巾", "爽朗", "252攻/252速/4特防", listOf("龙之俯冲", "暗影爪", "大字爆炎", "急速折返"), 28.5),
            MoveSet("dragapult", "特攻", "压迫感", "讲究眼镜", "胆小", "252特攻/252速/4防", listOf("龙之波动", "暗影球", "喷射火焰", "电磁波"), 8.7)
        ),
        "glimmora" to listOf(
            MoveSet("glimmora", "腮攻", "腐蚀之体", "气势披带", "胆小", "252特攻/252速/4防", listOf("力量宝石", "大地之力", "能源球", "隐形岩"), 25.3)
        ),
        "iron-valiant" to listOf(
            MoveSet("iron-valiant", "物攻", "夸克充能", "生命宝珠", "爽朗", "252攻/252速/4特防", listOf("近身战", "月亮之力", "影子偷袭", "剑舞"), 22.1)
        ),
        "kingambit" to listOf(
            MoveSet("kingambit", "物攻", "大将", "讲究头带", "固执", "252攻/252速/4特防", listOf("突袭", "铁头", "暗颈", "蛮力"), 30.2),
            MoveSet("kingambit", "受向", "大将", "凸凸头盔", "淘气", "252HP/252防/4攻", listOf("突袭", "铁头", "暗颈", "剑舞"), 14.5)
        ),
        "heatran" to listOf(
            MoveSet("heatran", "腮攻", "引火", "吃剩的东西", "胆小", "252特攻/252速/4HP", listOf("喷射火焰", "大地之力", "恶之波动", "隐形岩"), 26.8),
            MoveSet("heatran", "受向", "引火", "吃剩的东西", "大胆", "252HP/252防/4特防", listOf("喷射火焰", "大地之力", "铁壁", "熔岩风暴"), 18.3)
        ),
        "landorus-therian" to listOf(
            MoveSet("landorus-therian", "物攻", "威吓", "凸凸头盔", "淘气", "252HP/252防/4攻", listOf("地震", "急速折返", "隐形岩", "岩崩"), 32.1),
            MoveSet("landorus-therian", "腮攻", "威吓", "生命宝珠", "固执", "252攻/252速/4HP", listOf("地震", "岩崩", "蛮力", "剑舞"), 11.5)
        ),
        "garchomp" to listOf(
            MoveSet("garchomp", "物攻", "粗糙皮肤", "讲究头带", "爽朗", "252攻/252速/4特防", listOf("地震", "龙之爪", "岩崩", "铁头"), 19.2),
            MoveSet("garchomp", "剑舞", "粗糙皮肤", "气势披带", "爽朗", "252攻/252速/4HP", listOf("地震", "龙之爪", "剑舞", "岩崩"), 12.8)
        ),
        "weavile" to listOf(
            MoveSet("weavile", "物攻", "压力", "讲究头带", "爽朗", "252攻/252速/4特防", listOf("冰柱坠击", "暗颈", "低踢", "拍落"), 20.5)
        ),
        "rotom-wash" to listOf(
            MoveSet("rotom-wash", "腮攻", "漂浮", "吃剩的东西", "胆小", "252特攻/252速/4HP", listOf("水炮", "十万伏特", "恶之波动", "急速折返"), 16.8)
        ),
        "ferrothorn" to listOf(
            MoveSet("ferrothorn", "受向", "铁刺", "吃剩的东西", "淘气", "252HP/252防/4特防", listOf("寄生种子", "鼓掌", "隐形岩", "陀螺球"), 18.9)
        ),
        "tornadus-therian" to listOf(
            MoveSet("tornadus-therian", "腮攻", "恶作剧之心", "生命宝珠", "爽朗", "252特攻/252速/4防", listOf("热风", "暴风", "急速折返", "挑衅"), 15.4)
        ),
        "tapu-koko" to listOf(
            MoveSet("tapu-koko", "腮攻", "电气制造者", "生命宝珠", "胆小", "252特攻/252速/4防", listOf("十万伏特", "月亮之力", "急速折返", "伏特替换"), 17.6)
        ),
        "urshifu" to listOf(
            MoveSet("urshifu", "物攻", "无形拳", "生命宝珠", "固执", "252攻/252速/4特防", listOf("水流连击", "近身战", "冰冰矛", "毒击"), 21.3)
        ),
        "volcarona" to listOf(
            MoveSet("volcarona", "特攻", "火焰之躯", "生命宝珠", "胆小", "252特攻/252速/4HP", listOf("虫鸣", "火焰放射", "精神强念", "蝶舞"), 16.2)
        ),
        "tyranitar" to listOf(
            MoveSet("tyranitar", "物攻", "扬沙", "讲究头带", "固执", "252攻/252速/4特防", listOf("咬碎", "岩崩", "冰冻拳", "拍落"), 14.5)
        ),
        "excadrill" to listOf(
            MoveSet("excadrill", "物攻", "沙之力", "讲究头带", "固执", "252攻/252速/4特防", listOf("地震", "铁头", "岩崩", "冰冻拳"), 13.2)
        ),
        "greninja" to listOf(
            MoveSet("greninja", "特攻", "变幻自如", "讲究眼镜", "胆小", "252特攻/252速/4防", listOf("水炮", "冰冻光束", "恶之波动", "打草结"), 11.9)
        ),
        "magearna" to listOf(
            MoveSet("magearna", "特攻", "灵魂之心", "生命宝珠", "胆小", "252特攻/252速/4防", listOf("铁壁光线", "月亮之力", "精神强念", "加农光炮"), 12.7)
        ),
        "celesteela" to listOf(
            MoveSet("celesteela", "受向", "铁壁", "吃剩的东西", "淘气", "252HP/252防/4特防", listOf("火光冲腾", "重磅冲击", "铁壁", "寄生种子"), 15.8)
        ),
        "clefable" to listOf(
            MoveSet("clefable", "受向", "魔法守护", "吃剩的东西", "大胆", "252HP/252防/4特防", listOf("月光", "剧毒", "电磁波", "保存力量"), 14.1)
        ),
        "pawmot" to listOf(
            MoveSet("pawmot", "物攻", "铁拳", "生命宝珠", "爽朗", "252攻/252速/4特防", listOf("疯狂伏特", "近身战", "冰冻拳", "剑舞"), 10.3)
        ),
        "roaring-moon" to listOf(
            MoveSet("roaring-moon", "物攻", "古代活性", "生命宝珠", "固执", "252攻/252速/4特防", listOf("龙之俯冲", "暗颈", "铁头", "剑舞"), 18.7)
        ),
        "iron-hands" to listOf(
            MoveSet("iron-hands", "物攻", "夸克充能", "密探斗篷", "固执", "252HP/252攻/4特防", listOf("疯狂伏特", "近身战", "铁壁", "拍落"), 20.1)
        ),
        "archaludon" to listOf(
            MoveSet("archaludon", "特攻", "持久力", "生命宝珠", "胆小", "252特攻/252速/4防", listOf("加农光炮", "龙之波动", "铁壁光线", "伏特替换"), 16.4)
        ),
        "hydrapple" to listOf(
            MoveSet("hydrapple", "特攻", "再生力", "生命宝珠", "胆小", "252特攻/252速/4HP", listOf("龙之波动", "大地之力", "青草搅拌器", "铁壁光线"), 12.3)
        ),
        "gliscor" to listOf(
            MoveSet("gliscor", "受向", "中毒免疫", "吃剩的东西", "淘气", "252HP/252防/4特防", listOf("地震", "剧毒", "保护", "剑舞"), 22.4)
        )
    )

    fun getMoveSets(pokemonName: String): List<MoveSet> =
        allMoveSets[pokemonName.lowercase()] ?: emptyList()

    fun getTopMoveSet(pokemonName: String): MoveSet? =
        allMoveSets[pokemonName.lowercase()]?.maxByOrNull { it.usageRate }

    fun getAllPokemonNames(): List<String> = allMoveSets.keys.toList()
}
