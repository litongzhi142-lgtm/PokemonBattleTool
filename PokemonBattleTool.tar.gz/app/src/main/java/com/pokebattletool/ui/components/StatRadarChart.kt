package com.pokebattletool.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokebattletool.domain.model.BaseStats
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun StatRadarChart(
    stats: BaseStats,
    modifier: Modifier = Modifier,
    highlightColor: Color = MaterialTheme.colorScheme.primary,
    maxValue: Int = 255,
    size: Int = 200
) {
    val labels = listOf("HP", "攻击", "防御", "特攻", "特防", "速度")
    val values = listOf(stats.hp, stats.attack, stats.defense, stats.spAtk, stats.spDef, stats.speed)

    Box(modifier = modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.dp.toPx() / 2
            val cy = size.dp.toPx() / 2
            val r = min(cx, cy) * 0.85f
            val step = 2 * Math.PI / 6

            for (level in 1..5) {
                val lr = r * level / 5
                val p = Path()
                for (i in 0..5) {
                    val a = i * step - Math.PI / 2
                    val x = cx + lr * cos(a).toFloat()
                    val y = cy + lr * sin(a).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, Color.LightGray.copy(alpha = 0.3f), style = Stroke(1f))
            }

            for (i in 0..5) {
                val a = i * step - Math.PI / 2
                drawLine(Color.LightGray, Offset(cx, cy),
                    Offset(cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat()), 1f)
            }

            val vp = Path()
            for (i in 0..5) {
                val a = i * step - Math.PI / 2
                val vr = r * (values[i].toFloat() / maxValue).coerceAtMost(1f)
                val x = cx + vr * cos(a).toFloat()
                val y = cy + vr * sin(a).toFloat()
                if (i == 0) vp.moveTo(x, y) else vp.lineTo(x, y)
            }
            vp.close()
            drawPath(vp, highlightColor.copy(alpha = 0.3f))
            drawPath(vp, highlightColor, style = Stroke(2.dp.toPx()))

            for (i in 0..5) {
                val a = i * step - Math.PI / 2
                val vr = r * (values[i].toFloat() / maxValue).coerceAtMost(1f)
                drawCircle(highlightColor, 4.dp.toPx(), Offset(cx + vr * cos(a).toFloat(), cy + vr * sin(a).toFloat()))
            }

            for (i in 0..5) {
                val a = i * step - Math.PI / 2
                val lr = r + 20.dp.toPx()
                val x = cx + lr * cos(a).toFloat()
                val y = cy + lr * sin(a).toFloat()
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        textSize = 11.sp.toPx(); color = android.graphics.Color.DKGRAY
                        textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true
                    }
                    drawText(labels[i], x, y + 5.dp.toPx(), paint)
                    val vp2 = android.graphics.Paint().apply {
                        textSize = 10.sp.toPx(); color = highlightColor.hashCode()
                        textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true; isFakeBoldText = true
                    }
                    drawText(values[i].toString(), x, y + 18.dp.toPx(), vp2)
                }
            }
        }
    }
}

@Composable
fun StatBar(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    val fraction = (value.toFloat() / 255f).coerceIn(0f, 1f)
    Row(modifier = modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(36.dp), fontWeight = FontWeight.Medium)
        Text(value.toString(), style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(32.dp), fontWeight = FontWeight.Bold)
        Box(modifier = Modifier.weight(1f).height(12.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                drawRoundRect(Color.LightGray.copy(alpha = 0.3f), size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
                drawRoundRect(color, size = size.copy(width = size.width * fraction), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
            }
        }
    }
}

@Composable
fun StatSummary(stats: BaseStats, highlightColor: Color = MaterialTheme.colorScheme.primary, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        StatRadarChart(stats = stats, highlightColor = highlightColor)
        Spacer(Modifier.height(16.dp))
        Column(Modifier.fillMaxWidth()) {
            stats.toList().forEach { (label, value) ->
                StatBar(label, value, when { value >= 120 -> Color(0xFF4CAF50); value >= 80 -> highlightColor; else -> Color(0xFFFF9800) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("种族值总和: ${stats.total}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            color = when { stats.total >= 600 -> Color(0xFFFFD700); stats.total >= 500 -> highlightColor; else -> MaterialTheme.colorScheme.onSurface })
    }
}
