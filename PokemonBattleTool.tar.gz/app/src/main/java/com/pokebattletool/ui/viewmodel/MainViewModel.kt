package com.pokebattletool.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pokebattletool.data.repository.PokemonRepository
import com.pokebattletool.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: PokemonRepository) : ViewModel() {
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery
    private val _searchResults = MutableStateFlow<List<Pokemon>>(emptyList())
    val searchResults: StateFlow<List<Pokemon>> = _searchResults
    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching
    private val _currentPokemon = MutableStateFlow<Pokemon?>(null)
    val currentPokemon: StateFlow<Pokemon?> = _currentPokemon
    private val _currentMoveSets = MutableStateFlow<List<MoveSet>>(emptyList())
    val currentMoveSets: StateFlow<List<MoveSet>> = _currentMoveSets
    private val _myPokemon = MutableStateFlow<Pokemon?>(null)
    val myPokemon: StateFlow<Pokemon?> = _myPokemon
    private val _myMoveSet = MutableStateFlow<MoveSet?>(null)
    val myMoveSet: StateFlow<MoveSet?> = _myMoveSet
    private val _enemyPokemon = MutableStateFlow<Pokemon?>(null)
    val enemyPokemon: StateFlow<Pokemon?> = _enemyPokemon
    private val _enemyMoveSet = MutableStateFlow<MoveSet?>(null)
    val enemyMoveSet: StateFlow<MoveSet?> = _enemyMoveSet
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    val popularPokemon: List<String> = repository.getPopularPokemon()

    fun searchPokemon(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) { _searchResults.value = emptyList(); return }
        viewModelScope.launch {
            _isSearching.value = true
            try {
                val result = repository.searchPokemon(query)
                _searchResults.value = result?.let { listOf(it) } ?: emptyList()
                _error.value = if (result == null) "未找到宝可梦" else null
            } catch (e: Exception) { _error.value = "搜索失败: ${e.message}"; _searchResults.value = emptyList() }
            finally { _isSearching.value = false }
        }
    }

    fun loadPokemonDetail(pokemon: Pokemon) {
        _currentPokemon.value = pokemon
        _currentMoveSets.value = repository.getMoveSets(pokemon.name)
    }

    fun loadPokemonByName(name: String) {
        if (name.isBlank()) { _currentPokemon.value = null; _currentMoveSets.value = emptyList(); return }
        viewModelScope.launch {
            _isSearching.value = true
            try {
                val pokemon = repository.searchPokemon(name)
                if (pokemon != null) { _currentPokemon.value = pokemon; _currentMoveSets.value = repository.getMoveSets(pokemon.name) }
                else { _error.value = "未找到: $name" }
            } catch (e: Exception) { _error.value = "加载失败: ${e.message}" }
            finally { _isSearching.value = false }
        }
    }

    fun searchMyPokemon(name: String) {
        viewModelScope.launch {
            try {
                val p = repository.searchPokemon(name)
                if (p != null) { _myPokemon.value = p; _myMoveSet.value = repository.getMoveSets(p.name).firstOrNull() }
                else { _error.value = "未找到: $name" }
            } catch (e: Exception) { _error.value = "搜索失败: ${e.message}" }
        }
    }

    fun searchEnemyPokemon(name: String) {
        viewModelScope.launch {
            try {
                val p = repository.searchPokemon(name)
                if (p != null) { _enemyPokemon.value = p; _enemyMoveSet.value = repository.getMoveSets(p.name).firstOrNull() }
                else { _error.value = "未找到: $name" }
            } catch (e: Exception) { _error.value = "搜索失败: ${e.message}" }
        }
    }

    fun setMyPokemon(pokemon: Pokemon, moveSet: MoveSet?) {
        _myPokemon.value = pokemon
        _myMoveSet.value = moveSet ?: repository.getMoveSets(pokemon.name).firstOrNull()
    }

    fun setEnemyPokemon(pokemon: Pokemon, moveSet: MoveSet?) {
        _enemyPokemon.value = pokemon
        _enemyMoveSet.value = moveSet ?: repository.getMoveSets(pokemon.name).firstOrNull()
    }

    fun clearError() { _error.value = null }
}
