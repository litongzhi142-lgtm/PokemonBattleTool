package com.pokebattletool.ui.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pokebattletool.domain.model.Pokemon
import com.pokebattletool.domain.model.PokeType
import com.pokebattletool.domain.model.MoveSet
import com.pokebattletool.ui.components.StatSummary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PokemonDetailScreen(
    pokemon: Pokemon,
    moveSets: List<MoveSet>,
    onBackClick: () -> Unit,
    onAddToBattle: (Pokemon, MoveSet) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pokemon.chineseName) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.Default.ArrowBack, "返回") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            // 图片
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                AsyncImage(
                    model = pokemon.imageUrl,
                    contentDescription = pokemon.chineseName,
                    modifier = Modifier.size(180.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(pokemon.chineseName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Text("#${pokemon.id} ${pokemon.name}", style = MaterialTheme.typography.bodyMedium, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                pokemon.types.forEach { type ->
                    Surface(shape = RoundedCornerShape(4.dp), color = type.color) {
                        Text(type.displayName, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                }
            }

            // 图鉴描述
            pokemon.flavorText?.let {
                Spacer(Modifier.height(16.dp))
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text(it, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }

            // 种族值
            Spacer(Modifier.height(24.dp))
            Text("种族值", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            StatSummary(stats = pokemon.stats, highlightColor = pokemon.types.firstOrNull()?.color ?: MaterialTheme.colorScheme.primary)

            // 技能组
            Spacer(Modifier.height(24.dp))
            Text("常用技能组", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (moveSets.isEmpty()) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Text("暂无常用配置数据", modifier = Modifier.padding(16.dp), color = Color.Gray)
                }
            } else {
                moveSets.forEach { ms ->
                    MoveSetCard(ms, onAddToBattle = { onAddToBattle(pokemon, ms) })
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
fun MoveSetCard(moveSet: MoveSet, onAddToBattle: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.primary) {
                    Text(moveSet.role, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                }
                Text("使用率: ${moveSet.usageRate}%", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    ConfigItem("特性", moveSet.ability)
                    ConfigItem("道具", moveSet.item)
                    ConfigItem("性格", moveSet.nature)
                }
                Column(Modifier.weight(1f)) {
                    ConfigItem("努力值", moveSet.evs)
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("配招", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                moveSet.moves.forEach { move ->
                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Text(move, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onAddToBattle, modifier = Modifier.fillMaxWidth()) {
                Text("添加到对战辅助")
            }
        }
    }
}

@Composable
fun ConfigItem(label: String, value: String) {
    Row(Modifier.padding(vertical = 2.dp)) {
        Text("$label: ", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}
