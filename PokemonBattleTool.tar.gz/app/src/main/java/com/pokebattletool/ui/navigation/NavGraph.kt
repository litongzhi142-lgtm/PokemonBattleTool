package com.pokebattletool.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.pokebattletool.ui.home.HomeScreen
import com.pokebattletool.ui.detail.PokemonDetailScreen
import com.pokebattletool.ui.battle.BattleScreen
import com.pokebattletool.ui.viewmodel.MainViewModel

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Battle : Screen("battle")
}

@Composable
fun AppNavGraph(navController: NavHostController, viewModel: MainViewModel) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            val currentPokemon by viewModel.currentPokemon.collectAsState()
            val currentMoveSets by viewModel.currentMoveSets.collectAsState()

            currentPokemon?.let { pokemon ->
                PokemonDetailScreen(
                    pokemon = pokemon,
                    moveSets = currentMoveSets,
                    onBackClick = { viewModel.loadPokemonByName(""); navController.popBackStack() },
                    onAddToBattle = { p, ms -> viewModel.setMyPokemon(p, ms); navController.navigate(Screen.Battle.route) }
                )
            } ?: HomeScreen(
                viewModel = viewModel,
                onPokemonClick = { pokemon -> viewModel.loadPokemonDetail(pokemon) },
                onBattleClick = { navController.navigate(Screen.Battle.route) }
            )
        }

        composable(Screen.Battle.route) {
            val myPokemon by viewModel.myPokemon.collectAsState()
            val myMoveSet by viewModel.myMoveSet.collectAsState()
            val enemyPokemon by viewModel.enemyPokemon.collectAsState()
            val enemyMoveSet by viewModel.enemyMoveSet.collectAsState()

            BattleScreen(
                myPokemon = myPokemon,
                myMoveSet = myMoveSet,
                enemyPokemon = enemyPokemon,
                enemyMoveSet = enemyMoveSet,
                onSearchMy = { name -> viewModel.searchMyPokemon(name) },
                onSearchEnemy = { name -> viewModel.searchEnemyPokemon(name) },
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
