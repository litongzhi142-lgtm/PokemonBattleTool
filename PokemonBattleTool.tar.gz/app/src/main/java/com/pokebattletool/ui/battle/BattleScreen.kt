package com.pokebattletool.ui.battle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pokebattletool.domain.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BattleScreen(
    myPokemon: Pokemon?,
    myMoveSet: MoveSet?,
    enemyPokemon: Pokemon?,
    enemyMoveSet: MoveSet?,
    onSearchMy: (String) -> Unit,
    onSearchEnemy: (String) -> Unit,
    onBackClick: () -> Unit
) {
    var myInput by remember { mutableStateOf("") }
    var enemyInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("对战辅助") }, navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.Default.ArrowBack, "返回") } }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            // 双方选择
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                // 我方
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("我方", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(myInput, { myInput = it }, placeholder = { Text("名字/编号") }, singleLine = true, modifier = Modifier.width(140.dp))
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = { if (myInput.isNotBlank()) onSearchMy(myInput) }) { Text("确认") }
                    myPokemon?.let {
                        Spacer(Modifier.height(8.dp))
                        AsyncImage(model = it.imageUrl, contentDescription = it.chineseName,
                            modifier = Modifier.size(80.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                        Text(it.chineseName, fontWeight = FontWeight.Bold)
                        Row { it.types.forEach { t -> Surface(shape = RoundedCornerShape(4.dp), color = t.color) { Text(t.displayName, color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)) } } }
                    }
                }

                Text("VS", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color.Red, modifier = Modifier.align(Alignment.CenterVertically))

                // 对方
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("对方", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(enemyInput, { enemyInput = it }, placeholder = { Text("名字/编号") }, singleLine = true, modifier = Modifier.width(140.dp))
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = { if (enemyInput.isNotBlank()) onSearchEnemy(enemyInput) }) { Text("确认") }
                    enemyPokemon?.let {
                        Spacer(Modifier.height(8.dp))
                        AsyncImage(model = it.imageUrl, contentDescription = it.chineseName,
                            modifier = Modifier.size(80.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                        Text(it.chineseName, fontWeight = FontWeight.Bold)
                        Row { it.types.forEach { t -> Surface(shape = RoundedCornerShape(4.dp), color = t.color) { Text(t.displayName, color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)) } } }
                    }
                }
            }

            if (myPokemon != null && enemyPokemon != null) {
                Spacer(Modifier.height(24.dp))

                // === 速度线 ===
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("速度线分析", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(12.dp))
                        val mySpd = myPokemon.stats.speed; val enSpd = enemyPokemon.stats.speed
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("我方", color = Color.Gray); Text("$mySpd", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium) }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("差值", color = Color.Gray)
                                val d = mySpd - enSpd
                                Text(if (d > 0) "+$d" else "$d", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium,
                                    color = if (d > 0) Color(0xFF4CAF50) else if (d < 0) Color(0xFFF44336) else Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) { Text("对方", color = Color.Gray); Text("$enSpd", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium) }
                        }
                        Spacer(Modifier.height(12.dp))
                        Surface(shape = RoundedCornerShape(8.dp), color = if (mySpd > enSpd) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)) {
                            Text(if (mySpd > enSpd) "✓ 我方速度更快，可先手出招" else if (mySpd < enSpd) "✗ 对方速度更快，考虑先制技能" else "速度相同，随机先手",
                                modifier = Modifier.padding(12.dp), color = if (mySpd > enSpd) Color(0xFF2E7D32) else Color(0xFFC62828))
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // === 种族值对比 ===
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("种族值对比", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(12.dp))
                        val labels = listOf("HP", "攻击", "防御", "特攻", "特防", "速度")
                        val myS = with(myPokemon.stats) { listOf(hp, attack, defense, spAtk, spDef, speed) }
                        val enS = with(enemyPokemon.stats) { listOf(hp, attack, defense, spAtk, spDef, speed) }
                        labels.forEachIndexed { i, l ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${myS[i]}", Modifier.width(36.dp), fontWeight = if (myS[i] > enS[i]) FontWeight.Bold else FontWeight.Normal,
                                    color = if (myS[i] > enS[i]) Color(0xFF4CAF50) else if (myS[i] < enS[i]) Color(0xFFF44336) else Color.Gray)
                                Text(l, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                Text("${enS[i]}", Modifier.width(36.dp), fontWeight = if (enS[i] > myS[i]) FontWeight.Bold else FontWeight.Normal,
                                    color = if (enS[i] > myS[i]) Color(0xFF4CAF50) else if (enS[i] < myS[i]) Color(0xFFF44336) else Color.Gray)
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("总和: ${myPokemon.stats.total}", fontWeight = FontWeight.Bold)
                            Text("总和: ${enemyPokemon.stats.total}", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // === 推荐出招 ===
                myMoveSet?.let { ms ->
                    Spacer(Modifier.height(16.dp))
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("推荐出招", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(Modifier.height(8.dp))
                            Text("配置: ${ms.role} / ${ms.item} / ${ms.nature}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("努力值: ${ms.evs}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(Modifier.height(8.dp))
                            ms.moves.forEachIndexed { i, m ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.primary) {
                                        Text("${i + 1}", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    Text(m, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }

                // === 属性克制 ===
                Spacer(Modifier.height(16.dp))
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("属性克制参考", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        val eff = calcEffectiveness(myPokemon.types, enemyPokemon.types)
                        Text("我方攻击对方: ${eff}x",
                            fontWeight = FontWeight.Bold,
                            color = when { eff > 1 -> Color(0xFF4CAF50); eff < 1 -> Color(0xFFF44336); else -> Color.Gray })
                    }
                }
            }
        }
    }
}

private fun calcEffectiveness(atk: List<PokeType>, def: List<PokeType>): Double {
    val t = atk.firstOrNull() ?: return 1.0
    val d = def.firstOrNull() ?: return 1.0
    val se = mapOf(
        PokeType.FIRE to listOf(PokeType.GRASS, PokeType.ICE, PokeType.BUG, PokeType.STEEL),
        PokeType.WATER to listOf(PokeType.FIRE, PokeType.GROUND, PokeType.ROCK),
        PokeType.GRASS to listOf(PokeType.WATER, PokeType.GROUND, PokeType.ROCK),
        PokeType.ELECTRIC to listOf(PokeType.WATER, PokeType.FLYING),
        PokeType.ICE to listOf(PokeType.GRASS, PokeType.GROUND, PokeType.FLYING, PokeType.DRAGON),
        PokeType.FIGHTING to listOf(PokeType.NORMAL, PokeType.ICE, PokeType.ROCK, PokeType.STEEL),
        PokeType.GROUND to listOf(PokeType.FIRE, PokeType.ELECTRIC, PokeType.POISON, PokeType.ROCK, PokeType.STEEL),
        PokeType.FLYING to listOf(PokeType.GRASS, PokeType.FIGHTING, PokeType.BUG),
        PokeType.PSYCHIC to listOf(PokeType.FIGHTING, PokeType.POISON),
        PokeType.ROCK to listOf(PokeType.FIRE, PokeType.ICE, PokeType.FLYING, PokeType.BUG),
        PokeType.GHOST to listOf(PokeType.PSYCHIC, PokeType.GHOST),
        PokeType.DRAGON to listOf(PokeType.DRAGON),
        PokeType.DARK to listOf(PokeType.PSYCHIC, PokeType.GHOST),
        PokeType.STEEL to listOf(PokeType.ICE, PokeType.ROCK, PokeType.FAIRY),
        PokeType.FAIRY to listOf(PokeType.FIGHTING, PokeType.DRAGON, PokeType.DARK),
        PokeType.POISON to listOf(PokeType.GRASS, PokeType.FAIRY),
        PokeType.BUG to listOf(PokeType.GRASS, PokeType.PSYCHIC, PokeType.DARK)
    )
    val nve = mapOf(
        PokeType.FIRE to listOf(PokeType.FIRE, PokeType.WATER, PokeType.ROCK, PokeType.DRAGON),
        PokeType.WATER to listOf(PokeType.WATER, PokeType.GRASS, PokeType.DRAGON),
        PokeType.GRASS to listOf(PokeType.FIRE, PokeType.GRASS, PokeType.POISON, PokeType.FLYING, PokeType.BUG, PokeType.DRAGON, PokeType.STEEL),
        PokeType.ELECTRIC to listOf(PokeType.ELECTRIC, PokeType.GRASS, PokeType.DRAGON),
        PokeType.ICE to listOf(PokeType.FIRE, PokeType.WATER, PokeType.ICE, PokeType.STEEL),
        PokeType.FIGHTING to listOf(PokeType.POISON, PokeType.FLYING, PokeType.PSYCHIC, PokeType.BUG, PokeType.GHOST, PokeType.FAIRY),
        PokeType.GROUND to listOf(PokeType.GRASS, PokeType.BUG),
        PokeType.FLYING to listOf(PokeType.ELECTRIC, PokeType.ROCK, PokeType.STEEL),
        PokeType.PSYCHIC to listOf(PokeType.PSYCHIC, PokeType.STEEL),
        PokeType.ROCK to listOf(PokeType.FIGHTING, PokeType.GROUND, PokeType.STEEL),
        PokeType.GHOST to listOf(PokeType.DARK),
        PokeType.DARK to listOf(PokeType.FIGHTING, PokeType.DARK, PokeType.FAIRY),
        PokeType.STEEL to listOf(PokeType.FIRE, PokeType.WATER, PokeType.ELECTRIC, PokeType.STEEL),
        PokeType.BUG to listOf(PokeType.FIRE, PokeType.FIGHTING, PokeType.POISON, PokeType.FLYING, PokeType.GHOST, PokeType.STEEL, PokeType.FAIRY),
        PokeType.POISON to listOf(PokeType.POISON, PokeType.GROUND, PokeType.GHOST),
        PokeType.DRAGON to listOf(PokeType.STEEL)
    )
    return when {
        se[t]?.contains(d) == true -> 2.0
        nve[t]?.contains(d) == true -> 0.5
        else -> 1.0
    }
}
