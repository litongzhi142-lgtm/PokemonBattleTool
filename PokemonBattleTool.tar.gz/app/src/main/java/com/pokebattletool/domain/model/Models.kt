package com.pokebattletool.domain.model

import androidx.compose.ui.graphics.Color

data class Pokemon(
    val id: Int,
    val name: String,
    val chineseName: String,
    val types: List<PokeType>,
    val stats: BaseStats,
    val imageUrl: String?,
    val flavorText: String?
)

data class BaseStats(
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val spAtk: Int,
    val spDef: Int,
    val speed: Int
) {
    val total: Int get() = hp + attack + defense + spAtk + spDef + speed
    fun toList(): List<Pair<String, Int>> = listOf(
        "HP" to hp, "攻击" to attack, "防御" to defense,
        "特攻" to spAtk, "特防" to spDef, "速度" to speed
    )
}

enum class PokeType(val displayName: String, val color: Color) {
    NORMAL("一般", Color(0xFFA8A878)),
    FIRE("火", Color(0xFFF08030)),
    WATER("水", Color(0xFF6890F0)),
    GRASS("草", Color(0xFF78C850)),
    ELECTRIC("电", Color(0xFFF8D030)),
    ICE("冰", Color(0xFF98D8D8)),
    FIGHTING("格斗", Color(0xFFC03028)),
    POISON("毒", Color(0xFFA040A0)),
    GROUND("地面", Color(0xFFE0C068)),
    FLYING("飞行", Color(0xFFA890F0)),
    PSYCHIC("超能力", Color(0xFFF85888)),
    BUG("虫", Color(0xFFA8B820)),
    ROCK("岩石", Color(0xFFB8A038)),
    GHOST("幽灵", Color(0xFF705898)),
    DRAGON("龙", Color(0xFF7038F8)),
    DARK("恶", Color(0xFF705848)),
    STEEL("钢", Color(0xFFB8B8D0)),
    FAIRY("妖精", Color(0xFFF0B6BC))
}

data class MoveSet(
    val pokemonName: String,
    val role: String,
    val ability: String,
    val item: String,
    val nature: String,
    val evs: String,
    val moves: List<String>,
    val usageRate: Double
)

data class BattleSlot(
    val pokemon: Pokemon?,
    val moveSet: MoveSet? = null
)
