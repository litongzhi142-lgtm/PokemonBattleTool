# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.pokebattletool.data.remote.dto.** { *; }
-keep class com.pokebattletool.domain.model.** { *; }
